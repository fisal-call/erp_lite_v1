# ERP-Lite v1.0 — منتج نهائي قابل للتسليم

> نظام ERP مبسط عربي-أول (Arabic-first) RTL، مبني بـ React + FastAPI + PostgreSQL.

## المحتويات

```
ERP-Lite-v1.0/
├── erplite-backend/      # FastAPI + SQLAlchemy 2.0 (async) + asyncpg
│   ├── app/              # 58 ملف Python، 5,548 سطر، 74 routes
│   ├── tests/            # اختبارات sales flow + v1 finalization
│   ├── requirements.txt
│   └── .env.example
├── erplite-frontend/     # React 19 + TypeScript + Vite + Tailwind 4
│   ├── src/              # 93 ملف TS/TSX، 11,780 سطر
│   ├── dist/             # ✅ production build جاهز للنشر
│   ├── package.json
│   └── .env.example
├── sql/                  # 8 ملفات هجرات PostgreSQL
│   ├── ERP-Lite-001-System-Security-Core.sql
│   ├── ERP-Lite-002-Inventory.sql
│   ├── ERP-Lite-003-Purchasing-Sales.sql
│   ├── ERP-Lite-004-Accounting-Partitions.sql
│   ├── ERP-Lite-005-SeedData-RLS.sql
│   ├── ERP-Lite-006-Phase2-Views-Indexes-Functions.sql
│   ├── ERP-Lite-007-BootstrapRole.sql
│   └── ERP-Lite-008-CostCenters.sql
├── scripts/              # سكربتات تشغيل واختبار
│   ├── start_pg.py       # تشغيل PostgreSQL
│   ├── start_backend.py  # تشغيل Backend على :8000
│   ├── start_frontend.py # تشغيل Frontend dev server على :5173
│   ├── apply_migrations.py
│   ├── smoke_test.py
│   └── smoke_test_extended.py
└── docs/                 # توثيق شامل + تقارير التدقيق
    ├── ERP_LITE_V1_FINAL_AUDIT.md
    ├── FRONTEND_FINAL_ACCEPTANCE.md
    ├── BACKEND_ARCHITECTURE.md
    └── ERP-Lite-CHANGELOG.md
```

## المتطلبات

| المكون | الإصدار المطلوب |
|---|---|
| Python | 3.11+ |
| Node.js | 20+ |
| PostgreSQL | 15+ |
| npm | 10+ |

## خطوات التشغيل السريع

### 1) إعداد قاعدة البيانات

```bash
# إنشاء قاعدة بيانات PostgreSQL
createdb erplite

# إنشاء الأدوار (وفق ERP-Lite-005 + ERP-Lite-007)
psql -d erplite -f sql/ERP-Lite-005-SeedData-RLS.sql
psql -d erplite -f sql/ERP-Lite-007-BootstrapRole.sql

# تنفيذ الهجرات بالترتيب
psql -d erplite -f sql/ERP-Lite-001-System-Security-Core.sql
psql -d erplite -f sql/ERP-Lite-002-Inventory.sql
psql -d erplite -f sql/ERP-Lite-003-Purchasing-Sales.sql
psql -d erplite -f sql/ERP-Lite-004-Accounting-Partitions.sql
psql -d erplite -f sql/ERP-Lite-006-Phase2-Views-Indexes-Functions.sql
psql -d erplite -f sql/ERP-Lite-008-CostCenters.sql
```

### 2) إعداد الـ Backend

```bash
cd erplite-backend

# إنشاء ملف .env
cp .env.example .env
# عدّل القيم:
#   ERPLITE_DATABASE_URL=postgresql+asyncpg://erplite_app:PASSWORD@localhost:5432/erplite
#   ERPLITE_JWT_SECRET_KEY=<strong-random-string>

# تثبيت الاعتماديات
pip install -r requirements.txt

# التشغيل
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 3) إعداد الـ Frontend

```bash
cd erplite-frontend

# إنشاء ملف .env
cp .env.example .env
# (افتراضيًا يشير إلى http://localhost:8000/api/v1)

# تثبيت الاعتماديات
npm install

# تشغيل وضع التطوير
npm run dev
# → http://localhost:5173

# أو تشغيل نسخة الإنتاج (مبنية مسبقًا في dist/)
npm run preview
# أو خدمة dist/ عبر أي خادم ويب ثابت (nginx, serve, إلخ)
```

## التحقق من السلامة

```bash
# Frontend
cd erplite-frontend
npm run lint          # 0 warnings, 0 errors
npm run build         # build succeeds, dist/ generated

# Backend
cd erplite-backend
python -c "from app.main import app; print(f'OK: {len(app.routes)} routes')"
pytest tests/         # يتطلب PostgreSQL حية بالتكوين أعلاه
```

## نطاق النسخة v1.0

### ✅ مكتمل وجاهز للاستخدام
- **المصادقة**: JWT login/logout, ProtectedRoute, AuthContext
- **لوحة التحكم**: مؤشرات حقيقية (عدد العملاء/الموردين/الأصناف، حركات المخزون، أرصدة JE)
- **المبيعات**: العملاء (CRUD كامل) + أوامر البيع (إنشاء/عرض/تأكيد)
- **المشتريات**: الموردون (CRUD كامل) + أوامر الشراء (إنشاء/عرض/تأكيد)
- **المخزون**: الأصناف (CRUD) + الفئات + المستودعات + أرصدة المخزون + حركات المخزون
- **المحاسبة**: الحسابات (شجرة مع parent) + قيود اليومية (إنشاء/عرض/ترحيل) + ميزان المراجعة
- **التقارير**: 24 endpoint تقارير موصولة بالواجهة
- **الإعدادات**: البيانات المرجعية (عملات، دول، وحدات قياس) + السنوات المالية + شروط الدفع + معدلات الضرائب + مراكز التكلفة (CRUD مع optimistic locking)
- **التصميم**: RTL عربي-أول، تصميم متجاوب mobile-first، print CSS للمستندات
- **الأمان**: RLS على مستوى PostgreSQL، JWT، تحقق Zod على كل نموذج

### ⚠️ قيود معروفة (موثقة في تقرير التدقيق)
- بعض endpoints الـ Backend ناقصة (DELETE/PATCH لبعض الكيانات، تقارير P&L/Balance Sheet/General Ledger)
- لا توجد واجهة لإنشاء فواتير المبيعات/المشتريات أو سندات القبض/الدفع (الـ endpoints غير موجودة)
- لا توجد إدارة مستخدمين/أدوار/شركات في الواجهة (الـ endpoints موجودة جزئيًا)

هذه القيود موثقة بالكامل في `docs/FRONTEND_FINAL_ACCEPTANCE.md` و `docs/ERP_LITE_V1_FINAL_AUDIT.md`.

## المعمارية

```
┌─────────────────────┐     ┌─────────────────────┐     ┌──────────────────┐
│  React + Vite       │────▶│  FastAPI + Pydantic │────▶│  PostgreSQL      │
│  (Frontend)         │ JWT │  (Backend)          │ RLS │  (with RLS)      │
│  RTL Arabic-first   │◀────│  74 routes          │◀────│  8 SQL migrations│
└─────────────────────┘     └─────────────────────┘     └──────────────────┘
```

**المبادئ:**
1. الـ Backend هو مصدر الحقيقة — لا توجد بيانات وهمية في الواجهة
2. كل endpoint يستخدم UUID (لا تظهر المعرّفات الرقمية الداخلية)
3. RLS يُفرض على مستوى PostgreSQL عبر `SET LOCAL app.current_company_ids`
4. Optimistic locking عبر `expected_version_no` على كل mutation
5. كل قيد أعمال (BR-*) يُفرض في الـ Backend، الواجهة تعكسه فقط

## الترخيص
ملكي — مشروع ERP-Lite داخلي.
